#ifndef PROCESSOS_H
#define PROCESSOS_H

typedef struct Processo{
    int id;
    char numero[100];
    char data_ajuizamento[100];
    int id_classe;
    int id_assunto;
    int ano_eleicao;
} Processo;

int n, menu_principal;
void ordenar_processos(Processo processos[], int n);
void ordenar_decrescente_processos(Processo processos[], int n);
void remover_aspas(char *str);
void ler_processos(const char *filename, Processo processos[], int *n);
void escrever_processos(const char *filename, Processo processos[], int n);
void processosID_classe();
void contar_assuntos_distintos(Processo processos[], int n);
void calcular_dias_tramitacao(char *data_ajuizamento);

#endif // PROCESSOS_H
