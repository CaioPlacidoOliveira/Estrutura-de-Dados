#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <windows.h>
#include <stdio.h>
#include <time.h>
#include <assert.h>
#include "processos.h"

#define MAX_PROCESSOS 18395

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nShowCmd){
void ordenar_processos(Processo processos[], int n) {
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (processos[j].id > processos[j + 1].id) {
                Processo temp = processos[j];
                processos[j] = processos[j + 1];
                processos[j + 1] = temp;
            }
        }
    }
}

void ordenar_decrescente_processos(Processo processos[], int n) {
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (processos[j].id < processos[j + 1].id) {
                Processo temp = processos[j];
                processos[j] = processos[j + 1];
                processos[j + 1] = temp;
            }
        }
    }
}

void remover_aspas(char *str) {
    char *src = str;
    char *dst = str;
    while (*src) {
        if (*src != '"') {
            *dst = *src;
            dst++;
        }
        src++;
    }
    *dst = '\0';
}


void ler_processos(const char *filename, Processo processos[], int *n) {
    FILE *file = fopen(filename, "r");
    if (!file) {
        perror("Erro ao abrir o arquivo");
        exit(EXIT_FAILURE);
    }

    char linha[256];
    fgets(linha, sizeof(linha), file); // Ignorar cabeçalho

    int i = 0;
    while (fgets(linha, sizeof(linha), file)) {
        sscanf(linha, "%d,\"%[^\"]\",\"%[^\"]\",{%d},{%d},%d",
               &processos[i].id, processos[i].numero, processos[i].data_ajuizamento,
               &processos[i].id_classe, &processos[i].id_assunto, &processos[i].ano_eleicao);
        i++;
    }

    *n = i;

    fclose(file);
}

void escrever_processos(const char *filename, Processo processos[], int n) {
    FILE *file = fopen(filename, "w");
    if (!file) {
        perror("Erro ao abrir o arquivo");
        exit(EXIT_FAILURE);
    }

    fprintf(file, "\"id\",\"numero\",\"data_ajuizamento\",\"id_classe\",\"id_assunto\",\"ano_eleicao\"\n");
    for (int i = 0; i < n; i++) {
        fprintf(file, "%d,\"%s\",\"%s\",{%d},{%d},%d\n",
                processos[i].id, processos[i].numero, processos[i].data_ajuizamento,
                processos[i].id_classe, processos[i].id_assunto, processos[i].ano_eleicao);
    }

    fclose(file);
  }

void processosID_classe() {
    Processo processos[10];
    int n = 10;
    int total = 0;
    int id_classe_novo = 1;

    for (int i = 0; i < n; i++) {
        if (processos[i].id_classe == id_classe_novo) {
            total++;
        }
    }
printf("Existem %d processos vinculados a esse id_classe", total);
    system("pause");
}

void contar_assuntos_distintos(Processo processos[], int n) {
    int *marcados = (int *)calloc(20000, sizeof(int));  // Alocar dinamicamente e inicializar com 0
    if (!marcados) {
        printf("Erro ao alocar memória.\n");
        return;
    }

    int count = 0;
    for (int i = 0; i < n; i++) {
        int id_assunto = processos[i].id_assunto;
        if (id_assunto < 20000 && !marcados[id_assunto]) {
            marcados[id_assunto] = 1;
            count++;
        }
    }
    printf("Existem %d assuntos que constam nos processos\n", count);
    free(marcados);
    system("pause");
}

// Unit test for calcular_dias_tramitacao function
void calcular_dias_tramitacao(int dias_tramitacao) {
    assert(dias_tramitacao == 10);
    char data_ajuizamento;
    dias_tramitacao = calcular_dias_tramitacao(data_ajuizamento);


    // Test with a date from today
    time_t now = time(NULL);
    struct tm *tm = localtime(&now);
    strftime(data_ajuizamento, sizeof(data_ajuizamento), "%Y-%m-%d %H:%M:%S", tm);
    dias_tramitacao = calcular_dias_tramitacao(data_ajuizamento);
    assert(dias_tramitacao >= 0);
 }
}
