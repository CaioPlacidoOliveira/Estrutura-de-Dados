#include "processos.c"

Processo processos_global[MAX_PROCESSOS];

int main() {
    do {
		system("cls");
        printf("MENU PRINCIPAL\n\n");
        printf("[1]Ordenar os processos em ordem crescente\n");
		printf("[2]Ordenar os processos em ordem decrescente\n");
		printf("[3]Contar quantos processos estao vinculados a um determinado id_classe\n");
		printf("[4]Consultar quantos id_assuntos constam nos processos\n");
		printf("[5]Consultar a quantos dias um processo esta em tramitacao na justica\n");
        printf("[6]Sair\n");
		scanf("%d", &menu_principal);

		switch (menu_principal){
			case 1:
				ordenar_processos(processos_global, n);
                escrever_processos("processo_043_202409032338_ordenado.csv", processos_global, n);
                printf("\nProcessos ordenados e salvos em 'processo_043_202409032338_ordenado.csv'\n");
                system("pause");
				break;
			case 2:
				ordenar_decrescente_processos(processos_global, n);
                escrever_processos("processo_043_202409032338_ordenado_decrescente.csv", processos_global, n);
                printf("\nProcessos ordenados e salvos em 'processo_043_202409032338_decrescente.csv'\n");
                system("pause");
				break;
			case 3:
                processosID_classe();
				break;
            case 4:
                contar_assuntos_distintos(processos_global, n);
				break;
            case 5:
                calcular_dias_tramitacao(int dias_tramitacao);
				break;
            case 6:
                printf("Retornando ao menu");
                return menu_principal;
				break;
			default:
				printf("\nAlternativa invalida\n");
				system("pause");
				break;
		}
	}while (menu_principal!=6);
    return 0;
}
